import UIKit

//customer comes in.
"Hello"

//Worker
"WELCOME TO SUBWAY"
"What can I get for you?"

//Customer
"can I get a footlong spicy italian"

//Worker
"sure what type of bread"
"also what type of cheese"
"and toasted"
enum bread : CaseIterable {
    case Italian, Italianherbsandcheese, Honeyoat, grainwheat
}

enum cheese : CaseIterable {
    case Americancheese, cheddar, pepperjack, swiss
}

//Customer
"Italianherbsandcheese"
"american cheese"
"and yes toastead"

//Worker
"spicy italian right"

//custormer
"yes"

enum meat : CaseIterable {
    case peperoni, genoasalami
}

//Worker
"what veggies do you want"
"and what dressing"

//customer
"lettuce,onions,jalapeno,giordinada,olives,tomato,banana peper and cucumber"
"I will like chipotle southwest"

//worker
"ok"
enum veggies : CaseIterable {
    case lettuce, onions, jalapeno, giordinada, olives, tomato, bananapeper, cucumber
}

enum dressing : CaseIterable {
    case chipotlesouthwest, ranch, mayo, sriracha, bbq, mustard
}

//Worker
"is that all"

//customer
"yes"

print("I would like a Spicy Italian with a bread of \(bread.Italianherbsandcheese) and a \(cheese.Americancheese) and \(veggies.lettuce), \(veggies.onions), \(veggies.jalapeno), \(veggies.olives), \(veggies.tomato), \(veggies.cucumber), \(veggies.bananapeper), \(veggies.giordinada) and \(dressing.chipotlesouthwest).")
